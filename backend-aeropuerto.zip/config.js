'use strict'

const jwt = require('jsonwebtoken');

module.exports={

    JWT_SECRET: 'kjdfsgkhjk5hjsdhdskjfh435h3k4j5hkj34h5khjsdfgj43jh53jk5hkj',
    
    getJWT:function() {
        return 'kjdfsgkhjk5hjsdhdskjfh435h3k4j5hkj34h0rmgsdfgj43jh53jk5hkj';
    },

    getUser:function(headers) {
        let token = headers.authorization.split(' ')[1];
        return jwt.decode(token, this.JWT_SECRET).user;
    },

    getDB:function(){
        return 'mongodb://mongoadmin:adminaeropuerto@18.190.72.227:45500/admin';
    },

    getPrt:function(){
        return 45000;
    },

    getDataBase:function(){
        return "Aeropuerto";
    },
    getCollData:function(){
        return 'datos';
    },
    getCollUsrs:function(){
        return 'usuarios';
    },
    getCollCrcts:function(){
        return 'circuitos';
    },

    getS3:function(){
        return 'dome.test';
    }

};
