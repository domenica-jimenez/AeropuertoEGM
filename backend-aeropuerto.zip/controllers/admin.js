'use strict'

var db = require('../db');
const config = require('../config');
const bcrypt = require('bcryptjs');
const fetch = require('node-fetch');
const ObjectId = require('objectid');

//-------------------------------------------------------------------------------
///////////////////////////////////CREAR USUARIO
function crearUsuario (req, res){

    if (!req.body.username  || !req.body.pass || !req.body.nombre) {
        return res.status(400).send({message: "Incomplete parameters"});
    }

    let DB_Users =  db.get().db(config.getDataBase()).collection(config.getCollUsrs());
    let fecha = new Date()

    let search = {
        username: req.body.username
    }

    _get(DB_Users, search).then(
        result => {
            if (result.length == 0) {
                let user = {
                    username: req.body.username,
                    nombre: req.body.nombre,
                    pass: req.body.pass,

                    posicion: null,
                    circuito: null,
                    estado: true,
                    rol: "Usuario",
                    fechaCreacion: fecha
                }
                return _create(DB_Users, user);
            } else {
                if( result[0].estado ) return Promise.reject("Existing account");
                else return Promise.reject("Disabled account");
            }
        },
        error => {
            return Promise.reject(error);
        }
    ).then(
        result => {
            return res.status(200).send({message: "Success"});
        },
        error => {
            return res.status(402).send({message: error});
    });
}

///////////////////////////////////OBTENER USUARIOS
function obtenerUsuarios (req, res){

    let DB_Users =  db.get().db(config.getDataBase()).collection(config.getCollUsrs());
    let DB_path =  db.get().db(config.getDataBase()).collection(config.getCollCrcts());

    let search = { rol: "Usuario" };
    let filter = { 
        username: 1,
        nombre: 1,
        estado: 1,
        posicion: 1,
        circuito: 1 
    };
    let order = { nombre: 1 };

    _get(DB_Users, search, filter, order).then(
        result => {
            return Promise.all(result.map(x => {
                if (x.circuito) {
                    return new Promise((resolve, reject) => {
                        DB_path.aggregate([{ $match : {_id : new ObjectId( x.circuito), estado: true} }]).toArray (function (err, data) {
                            if(err){
                                reject("Data Base error");
                            }else{
                                if (data.length == 0) {
                                    x.circuito = null
                                    resolve (x)
                                }else {
                                    x.circuito = data[0].nombre
                                    resolve(x);
                                }
                                
                            }
                        })
                    });
                }else {
                    return Promise.resolve(x)
                }
            }));
        },
        error => {
            return res.status(402).send({message: error});
    }).then(
        result => {
            return res.status(200).send(result);
        },
        error => {
            return res.status(402).send({message: error});
    });
}
///////////////////////////////////EDITAR USUARIO
function editarUsuario (req, res){

    if (!req.body.id ) {
        return res.status(400).send({message: "Incomplete parameters"});
    }

    let DB_User =  db.get().db(config.getDataBase()).collection(config.getCollUsrs());

    let search = { _id: new ObjectId(req.body.id) };
    let update = { };

    _get(DB_User, search).then(
        result => {
            if (result.length == 0) return Promise.reject("Unknow path");
            else {
                if (req.body.nombre) update.nombre = req.body.nombre;
                if (req.body.pass) update.pass = req.body.pass;
                if (req.body.posicion) update.posicion = req.body.posicion;
                if (req.body.circuito) update.circuito = new ObjectId(req.body.circuito);

                return _update(DB_User, search, update);
            }
            
        },
        error => {
            return res.status(402).send({message: error});
    }).then(
        result => {
            return res.status(200).send({message: "Success"});
        },
        error => {
            return res.status(402).send({message: error});
    });
}

//-------------------------------------------------------------------------------
///////////////////////////////////CREAR CIRCUITO
function crearCircuito (req, res){

    if (!req.body.nombre || !req.body.inicio || !req.body.puntos ) {
        return res.status(400).send({message: "Incomplete parameters"});
    }

    let DB_path =  db.get().db(config.getDataBase()).collection(config.getCollCrcts());
    let fecha = new Date()

    let search = {
        nombre: req.body.nombre,
        estado: true
    }

    _get(DB_path, search).then(
        result => {
            if (result.length == 0) {
                let path = {
                    nombre: req.body.nombre,
                    inicio: req.body.inicio,
                    puntos: req.body.puntos,

                    estado: true,
                    fechaCreacion: fecha
                }
                return _create(DB_path, path);
            } else {
                if( result[0].estado ) return Promise.reject("Existing path");
                else return Promise.reject("Disabled path");
            }
        },
        error => {
            return Promise.reject(error);
        }
    ).then(
        result => {
            return res.status(200).send({message: "Success"});
        },
        error => {
            return res.status(402).send({message: error});
    });
}

///////////////////////////////////OBTENER CIRCUITOS
function obtenerCircuitos (req, res){

    let DB_path =  db.get().db(config.getDataBase()).collection(config.getCollCrcts());

    let search = { estado: true};
    let filter = { 
        nombre: 1,
        inicio: 1,
        puntos: 1 
    };
    let order = { nombre: 1 };

    _get(DB_path, search, filter, order).then(
        result => {
            return res.status(200).send(result);
        },
        error => {
            return res.status(402).send({message: error});
    });;
}

///////////////////////////////////EDITAR CIRCUITO
function editarCircuito (req, res){

    if (!req.body.id ) {
        return res.status(400).send({message: "Incomplete parameters"});
    }

    let DB_path =  db.get().db(config.getDataBase()).collection(config.getCollCrcts());

    let search = { _id: new ObjectId(req.body.id) };
    let update = { };

    _get(DB_path, search).then(
        result => {
            if (result.length == 0) return Promise.reject("Unknow path");
            else {
                if (req.body.nombre) update.nombre = req.body.nombre;
                if (req.body.inicio) update.inicio = req.body.inicio;
                if (req.body.puntos) update.puntos = req.body.puntos;

                return _update(DB_path, search, update);
            }
            
        },
        error => {
            return res.status(402).send({message: error});
    }).then(
        result => {
            return res.status(200).send({message: "Success"});
        },
        error => {
            return res.status(402).send({message: error});
    });
}

///////////////////////////////////ELIMINAR CIRCUITO
function eliminarCircuito (req, res){

    if (!req.body.id ) {
        return res.status(400).send({message: "Incomplete parameters"});
    }

    let DB_path =  db.get().db(config.getDataBase()).collection(config.getCollCrcts());

    let search = { _id: new ObjectId(req.body.id) };
    let update = { estado: false};

    _get(DB_path, search).then(
        result => {
            if (result.length == 0) return Promise.reject("Unknow path");
            else {
                return _update(DB_path, search, update);
            }
            
        },
        error => {
            return res.status(402).send({message: error});
    }).then(
        result => {
            return res.status(200).send({message: "Success"});
        },
        error => {
            return res.status(402).send({message: error});
    });
}


///////////////////////////////////     FUNCIONES       ///////////////////////////////////
function _get(DB, search, filter = "no filter", sort = "no sort"){

    return new Promise((resolve, reject) => {
        if (filter == "no filter" && sort == "no sort"){
            DB.aggregate([{ $match : search }]).toArray (function (err, data) {
                if(err){
                    reject("Data Base error");
                }else{
                    resolve(data);
                }
            })
        }else {
            DB.aggregate([{ $match : search }, { $project : filter },{ $sort : sort }]).toArray (function (err, data) {
                if(err){
                    reject("Data Base error");
                }else{
                    resolve(data);
                }
            })
        }
    });
}

function _create(DB,document){

    return new Promise((resolve, reject) => {
        DB.insertOne(document, (err, result) => {
            if(err){
                reject("Data Base error");
            }else{
                resolve(result);
            }
        })
    });
}

function _update(DB, search, document){
    
    return new Promise((resolve, reject) => {
        DB.findOneAndUpdate(search, {$set: document}, (err, data) => {
            if(err){
                reject("Data Base error");
            }else{
                resolve("Success");
            }
        })    
    });
}

module.exports = {
    crearUsuario,
    obtenerUsuarios,
    editarUsuario,
    crearCircuito,
    editarCircuito,
    obtenerCircuitos,
    eliminarCircuito
};

