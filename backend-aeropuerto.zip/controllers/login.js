'use strict'

var db = require('../db');
const config = require('../config');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

function login (req, res){

    if (!req.body.username || !req.body.password ) return res.status(400).send({message: "Incomplete parameters"});

    let search = {username: req.body.username};
    let DB = db.get().db(config.getDataBase()).collection(config.getCollUsrs());

    _get(DB, search).then(
        result => {
            if ( result.length == 0) return Promise.reject("Non-existing account");
            else return _verifyUser(result[0], req.body.password)
        }, error => {
            return Promise.reject(error)
        }
    ).then(
        result => {
            return res.status(200).send(result);
        },
        error => {
            return res.status(400).send({message: error});    
        }
    );
}

function _verifyUser(data, password){

        
    return new Promise((resolve, reject) => {
        if (!data.estado) {
            reject ("Account disable");                   
        }else {

            //if (bcrypt.compareSync(password, data.pass)) {
            if (password == data.pass) {
                    let payload = { 
                        user: data.username
                    };
                    let jwtUser = jwt.sign(payload,config.getJWT(),{expiresIn:'16h'});

                    let user_data ={
                        username: data.username,
                        nombre: data.nombre,
                        posicion: data.posicion,
                        circuito: data.circuito,
                        rol: data.rol,  
                    };

                    resolve({token: jwtUser, datos: user_data})

            }else {
                reject ("Incorrect password");
            }
        }
    
    });
}

///////////////////////////////////     FUNCIONES       ///////////////////////////////////
function _get(DB, search, filter = "no filter", sort = "no sort"){

    return new Promise((resolve, reject) => {
        if (filter == "no filter" && sort == "no sort"){
            DB.aggregate([{ $match : search }]).toArray (function (err, data) {
                if(err){
                    reject("Data Base error");
                }else{
                    resolve(data);
                }
            })
        }else {
            DB.aggregate([{ $match : search }, { $project : filter },{ $sort : sort }]).toArray (function (err, data) {
                if(err){
                    reject("Data Base error");
                }else{
                    resolve(data);
                }
            })
        }
    });
}

module.exports = {
    login
};
