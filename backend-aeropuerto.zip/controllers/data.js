'use strict'

var db = require('../db');
const config = require('../config');
const fs = require('fs')
const S3 = require('aws-sdk/clients/s3');
const ObjectId = require('objectid');

const bucketName = config.getS3();
const AWS_ACCESS_KEY_ID = 'AKIAW2THBOUAWRAFWVH4';
const AWS_SECRET_ACCESS_KEY = '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';

// Crear un Dato
function crearDato(req,res){

    if (!req.files || req.files.length == 0 || !req.files.archivo) {
        return res.status(400).send({mensaje: 'No existen archivos'})
    }

    if (!req.middlewareParameters.circuito || !req.middlewareParameters.posicion) {
        return res.status(400).send({mensaje: 'Se debe configurar al usuario primero'})
    }

    let DB = db.get().db(config.getDataBase()).collection(config.getCollData());

    let username = req.middlewareParameters.username;
    let circuito = req.middlewareParameters.circuito;
    let posicion = req.middlewareParameters.posicion;
    let fecha = new Date()

    let storage =  new S3({
        accessKeyId: AWS_ACCESS_KEY_ID,
        secretAccessKey: AWS_SECRET_ACCESS_KEY,
        region: 'us-west-2'
    })

    let stream = fs.createReadStream(req.files.archivo.tempFilePath);

    let aux = {
        historial: [{username: username, fecha: fecha, posicion: posicion}],
        posicionActual: posicion,
        fechaCreacion: fecha,
        usuarioCreacion: username,
        circuito: circuito
    }

    let params = {
        Bucket: bucketName+'/imagenes',
        Key: req.files.archivo.name,
        Body: stream
    }

    storage.upload(params, function(err, data) {
        if (err){
            return res.status(400).send({mensaje: 'Error al subir el archivo'})
        }
        aux.archivo = data.Location

        DB.insertOne(aux , (err)=>{
                if(err){
                    return res.status(400).send({mensaje: 'Error al crear el dato.'});
                }else{
                    return res.status(200).send({mensaje:'Dato creado.'});
                }
            }
        )
    });

}

// Editar un Dato
function editarDato(req,res){

    if(!req.body.id){
        return res.status(400).send({message: 'Parámetros incompletos.'});
    }

    if (!req.middlewareParameters.circuito || !req.middlewareParameters.posicion) {
        return res.status(400).send({mensaje: 'Se debe configurar al usuario primero'})
    }

    var DB = db.get().db(config.getDataBase()).collection(config.getCollData());
    
    let username = req.middlewareParameters.username;
    let posicion = req.middlewareParameters.posicion;
    let fecha = new Date()

    let search = {_id: new ObjectId(req.body.id)};
    let update = {posicionActual: posicion}
    let agregate = {historial: {username: username, fecha: fecha, posicion: posicion}}

    

    DB.findOneAndUpdate(search, {$set: update, $push: agregate}, function (err,result) {
        if(err){
            return res.status(500).send({message:"Error al actualizar."});
        }else{
            if(result.value == null){
                return res.status(200).send({message:"No existe."});
            }else{
                return res.status(200).send({message:"Actualizacion exitosa."});
            }
        }
    })
}

// Mostrar todos los Datos
function obtenerDatos(req,res){

    if (!req.middlewareParameters.circuito) {
        return res.status(400).send({mensaje: 'Se debe configurar al usuario primero'})
    }

    let circuito = req.middlewareParameters.circuito;

    let search ={circuito: new ObjectId(circuito)};
    let filtro = {projection:{historial: 0, fechaCreacion: 0, usuarioCreacion: 0, circuito: 0}};

    let DB = db.get().db(config.getDataBase()).collection(config.getCollData());

    DB.find(search, filtro).toArray(function (err,result) {
        if(err){
            return res.status(500).send({message:"Error en la petición."});
        }else{
            if(result.length == 0){
                return res.status(200).send({message:"No existen."});
            }else{
                return res.status(200).send(result);
            }
        }
    })
}

// Mostrar un dato
function obtenerDato(req,res){

    if(!req.body.id){
        return res.status(400).send({message: 'Parametros incompletos'});
    }

    let search ={_id: new ObjectId(req.body.id)};
    let filtro = {projection:{historial: 0}};

    let DB = db.get().db(config.getDataBase()).collection(config.getCollData());

    DB.find(search,filtro).toArray(function (err,result) {
        if(err){
            return res.status(500).send({message:"Error en la petición."});
        }else{
            if(result.length == 0){
                return res.status(200).send({message:"No existen."});
            }else{
                return res.status(200).send(result);
            }
        }
    })
}


module.exports = {
    crearDato,
    editarDato,
    obtenerDatos,
    obtenerDato
};

