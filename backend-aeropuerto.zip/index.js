'use strict'

const db = require('./db');
const app = require('./app');
const config = require('./config');

const port =  config.getPrt(); 

db.connect(config.getDB(), function(err) {
    if (err) {
        return console.log(err)
    } else {
        console.log("Conexion establecida...");
        app.listen(port, function(){
        console.log("API inicializada sobre el puerto "+port);
        })
    }
});