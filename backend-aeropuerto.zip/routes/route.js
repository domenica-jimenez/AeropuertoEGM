'use strict'

const express = require('express');
const router = express.Router();

const AdmnController = require('../controllers/admin');
const DataController = require('../controllers/data');
const Middleware = require('../middleware/autorizacion');
const LgnController = require('../controllers/login');


// Ruta para Autenticar
router.patch('/login', LgnController.login);

// Rutas para Usuarios
router.post('/crearUsuario', Middleware.admin, AdmnController.crearUsuario);
router.get('/obtenerUsuarios', Middleware.admin, AdmnController.obtenerUsuarios);
router.put('/editarUsuario', Middleware.admin, AdmnController.editarUsuario);

//router.patch('/mostrarUsuario', Middleware.autenticacion, usuarios.mostrarUsuario);
//router.patch('/actualizarEstado', Middleware.autenticacion, usuarios.actualizarEstado);

//Rutas para Circuitos
router.post('/crearCircuito', Middleware.admin, AdmnController.crearCircuito);
router.put('/editarCircuito', Middleware.admin, AdmnController.editarCircuito);
router.get('/obtenerCircuitos', Middleware.admin, AdmnController.obtenerCircuitos);
router.delete('/eliminarCircuito', Middleware.admin, AdmnController.eliminarCircuito);

// Rutas para Datos
router.post('/crearDato', Middleware.verification, DataController.crearDato);
router.put('/editarDato', Middleware.verification, DataController.editarDato);
router.get('/obtenerDatos', Middleware.verification, DataController.obtenerDatos);
router.get('/obtenerDato', Middleware.verification, DataController.obtenerDato);


module.exports = router;