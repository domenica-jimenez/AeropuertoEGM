'use strict'

var config = require('../config');
var db = require('../db');

exports.admin = function(req, res, next) {

    if (!req.headers.authorization )  return res.status(402).send({message: "Incomplete parameters"});

    let user = config.getUser(req.headers);

    if (!user) return res.status(402).send({message: "Incomplete parameters"});


    _searchUser(user).then(
        result=>{
            
            if ( !result.estado || result.rol != "Admin") return res.status(402).send({message: "Unauthorized user"});
            req.middlewareParameters = {
                username: result.username
            };
            next();
        },
        error=>{
            return res.status(402).send({message: error});
        }
    )

};

exports.verification = function(req, res, next) {

    if (!req.headers.authorization )  return res.status(402).send({message: "Incomplete parameters"});

    let user = config.getUser(req.headers);

    if (!user) return res.status(402).send({message: "Incomplete parameters"});


    _searchUser(user).then(
        result=>{
            
            if ( !result.estado ) return res.status(402).send({message: "Invalid user"});
            req.middlewareParameters = {
                username: result.username,
                circuito: result.circuito,
                posicion: result.posicion
            };
            next();
        },
        error=>{
            return res.status(402).send({message: error});
        }
    )
};

function _searchUser(user){
    
    let DB = db.get().db(config.getDataBase()).collection(config.getCollUsrs());
    
    let search = {$or: [{username: user}, {email: user}]};

    let filter = {
        _id:0,
        username:1,
        rol: 1,
        estado:1,
        circuito:1,
        posicion:1,
    }

    const userDB = new Promise((resolve, reject) => {
        DB.aggregate([{ $match : search }, {$project: filter}]).toArray (function (err,data) {
            if (err){
                reject ("Data Base error");
            }else {
                if (data.length == 0) reject('Unknow user');
                resolve(data[0]);
            }
        });
    });
    return userDB;
}

